#!/bin/bash

set -e  # oprește la primul eșec

echo "📦 Building Docker images for all services..."

docker build -t demo-order-service -f docker/Dockerfile.order-service .
docker build -t demo-product-service -f docker/Dockerfile.product-service .
docker build -t demo-store-front -f docker/Dockerfile.store-front .
docker build -t demo-store-admin -f docker/Dockerfile.store-admin .
docker build -t demo-ai-service -f docker/Dockerfile.ai-service .
docker build -t demo-makeline-service -f 
docker/Dockerfile.makeline-service .
docker build -t demo-virtual-customer -f 
docker/Dockerfile.virtual-customer .
docker build -t demo-virtual-worker -f docker/Dockerfile.virtual-worker .

echo "✅ Done building all Docker images!"

