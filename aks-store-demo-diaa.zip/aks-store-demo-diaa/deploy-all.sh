#!/bin/bash

set -e  # Oprește la prima eroare

echo "🚀 Applying Kubernetes manifests..."

kubectl apply -f k8s/

echo "✅ All services deployed."

echo "🌐 Verifying ingress setup..."
kubectl get ingress

echo "💡 Try accessing: http://store.local/order (sau alte path-uri din ingress.yaml)"

